=====
Instant eSports Base
=====

ies_base is a simple Django app that combines some basic functionality.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "ies-base" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = (
        ...
        'ies_base',
    )
